public interface State {
    public void parteilob();

    public void parteitadel();

    public void wirtschaftslob();

    public void wirtschaftskritik();

    public void erwischt();
}
