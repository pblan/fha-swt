public interface IAbrechnungsart {
    public void bezahlen();
}
